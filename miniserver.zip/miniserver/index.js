const express = require('express');
const app = express();
app.use(express.static('public'));

app.get('/hello-world', (req, res)=> {
  res.writeHead(200, { 'content-type': 'text/plain'});
  res.end('Hello World!\n');
});

app.listen(3000, '127.0.0.1', ()=>{
  console.log('Listening on 127.0.0.1:3000');
});